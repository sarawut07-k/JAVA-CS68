def community_shop_checkout(price, is_member, amount_paid):
    # TODO: 1. คำนวณส่วนลดสมาชิก 5% ด้วยเทคนิค (bool x ตัวเลข) ห้ามใช้ if
    # ถ้า is_member เป็น True จะมีค่าเท่ากับ 1, ถ้า False จะมีค่าเท่ากับ 0
    discount = (price * 0.05) * is_member
    price_after_discount = price - discount
    
    # TODO: 2. คำนวณ VAT 7% จากยอดหลังหักส่วนลด
    vat = price_after_discount * 0.07
    total_price = price_after_discount + vat
    
    # TODO: 3. ปัดยอดสุทธิเป็นบาทเต็ม (บวก 0.5 แล้วตัดเศษทิ้งเพื่อให้ปัดเศษขึ้นลงอย่างถูกต้อง)
    final_total = int(total_price + 0.5)
    
    # TODO: 4. คำนวณเงินทอน
    change = amount_paid - final_total
    
    # TODO: 5. แตกเงินทอนเป็นธนบัตรและเหรียญด้วย // และ %
    remaining = change
    
    b1000 = remaining // 1000
    remaining = remaining % 1000
    
    b500 = remaining // 500
    remaining = remaining % 500
    
    b100 = remaining // 100
    remaining = remaining % 100
    
    b50 = remaining // 50
    remaining = remaining % 50
    
    b20 = remaining // 20
    remaining = remaining % 20
    
    c10 = remaining // 10
    remaining = remaining % 10
    
    c5 = remaining // 5
    remaining = remaining % 5
    
    c2 = remaining // 2
    remaining = remaining % 2
    
    c1 = remaining // 1
    
    # TODO: 6. จัดใบเสร็จด้วย f-string
    receipt = f"""
========================================
         ใบเสร็จรับเงินร้านค้าชุมชน
========================================
ยอดซื้อสินค้า:           {price:10.2f} บาท
ส่วนลดสมาชิก (7%):      {discount:10.2f} บาท
ยอดหลังหักส่วนลด:        {price_after_discount:10.2f} บาท
ภาษีมูลค่าเพิ่ม (VAT 7%):  {vat:10.2f} บาท
ยอดชำระสุทธิ (ปัดเศษ):     {final_total:10} บาท
========================================
รับเงินมา:              {amount_paid:10} บาท
เงินทอน:               {change:10} บาท
----------------------------------------
ทอนธนบัตร 1000 บาท:    {b1000:3} ใบ
ทอนธนบัตร 500 บาท:     {b500:3} ใบ
ทอนธนบัตร 100 บาท:     {b100:3} ใบ
ทอนธนบัตร 50 บาท:      {b50:3} ใบ
ทอนธนบัตร 20 บาท:      {b20:3} ใบ
ทอนเหรียญ 10 บาท:      {c10:3} เหรียญ
ทอนเหรียญ 5 บาท:       {c5:3} เหรียญ
ทอนเหรียญ 2 บาท:       {c2:3} เหรียญ
ทอนเหรียญ 1 บาท:       {c1:3} เหรียญ
========================================
"""
    return receipt

# ========================================
# TODO: กรณีทดสอบ 3 กรณี
# ========================================

# กรณีที่ 1: ซื้อ 100 บาท, เป็นสมาชิก (True), จ่าย 150 บาท
# ส่วนลด = 7 บาท -> เหลือ 93 บาท -> VAT 6.51 -> ยอดสุทธิ 99.51 (ปัดเป็น 100 บาท) -> ทอน 50 บาท
print(">>> กรณีทดสอบที่ 1 <<<")
print(community_shop_checkout(price=100, is_member=True, amount_paid=150))

# กรณีที่ 2: ซื้อ 2500 บาท, ไม่เป็นสมาชิก (False), จ่าย 3000 บาท
# ส่วนลด = 0 บาท -> เหลือ 2500 -> VAT 175 -> ยอดสุทธิ 2675 บาท -> ทอน 325 บาท
print(">>> กรณีทดสอบที่ 2 <<<")
print(community_shop_checkout(price=2500, is_member=False, amount_paid=3000))

# กรณีที่ 3: ซื้อ 1450 บาท, เป็นสมาชิก (True), จ่าย 2000 บาท
# ส่วนลด = 101.50 -> เหลือ 1348.50 -> VAT 94.40 -> ยอดสุทธิ 1442.90 (ปัดเป็น 1443 บาท) -> ทอน 557 บาท
print(">>> กรณีทดสอบที่ 3 <<<")
print(community_shop_checkout(price=1450, is_member=True, amount_paid=2000))